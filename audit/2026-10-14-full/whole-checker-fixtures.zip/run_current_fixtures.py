from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path(__file__).resolve().parent
repo = root.parent / "ProbabilisticSerial-review"
runtime = root.parent / "lean-runtime"
lean = runtime / "lean-4.19.0-linux/bin/lean"
original = (repo / "AllDeclarationsAudit.lean").read_text()
body = original[original.index("open Lean in\nrun_cmd do\n"):]
(root / "current-checker-body.txt").write_text(body)
env = os.environ.copy()
env["PATH"] = str(lean.parent) + ":" + env["PATH"]
env["LD_PRELOAD"] = str(runtime / "own-process-path.so")
env["LEAN_PATH"] = str(root)
results = {"body_sha256": hashlib.sha256(body.encode()).hexdigest(),
           "source_audit_sha256": hashlib.sha256(original.encode()).hexdigest(), "tests": []}
for module in ["ValidFixture", "ValidStringFixture", "SorryFixture", "PrivateSorryFixture", "OpaqueSorryFixture", "AxiomFixture"]:
    audit = root / f"CurrentAudit{module}.lean"
    audit.write_text(f"import {module}\nimport Lean.Util.CollectAxioms\n\n" + body)
    result = subprocess.run([str(lean), str(audit)], cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (root / f"{module}-current-audit.log").write_text(result.stdout)
    results["tests"].append({"module": module, "audit_exit_code": result.returncode})
    print(f"{module}: exit {result.returncode}", flush=True)
    print(result.stdout.strip(), flush=True)
(root / "current-results.json").write_text(json.dumps(results, indent=2) + "\n")
