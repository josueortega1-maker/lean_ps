import PrivateSorryFixture
import Lean.Util.CollectAxioms

open Lean in
run_cmd do
  let env ← getEnv
  let modules := env.imports.map (·.module) |>.filter
    (fun mod => mod != `Init && mod != `Lean.Util.CollectAxioms)
  if modules.isEmpty then
    throwError "No project modules selected for the full declaration audit"
  let mut moduleIndices : Array ModuleIdx := #[]
  for mod in modules do
    let some idx := env.getModuleIdx? mod
      | throwError "Required project module was not imported: {mod}"
    moduleIndices := moduleIndices.push idx
  let targets := env.constants.fold (init := #[]) fun names name info =>
    if info.isUnsafe then names else
      match env.getModuleIdxFor? name with
      | some idx => if moduleIndices.contains idx then names.push name else names
      | none => names
  if targets.isEmpty then
    throwError "No project declarations found in the imported modules"
  let (_, result) := ((do
    for name in targets do
      CollectAxioms.collect name).run env).run {}
  let allowed := #[`propext, `Classical.choice, `Quot.sound]
  for dependency in result.axioms do
    unless allowed.contains dependency do
      throwError "Unexpected dependency in project declarations: {dependency}"
  for mod in modules do
    let idx := env.getModuleIdx? mod
    let count : Nat := targets.foldl (fun n name =>
      if env.getModuleIdxFor? name == idx then n + 1 else n) 0
    logInfo m!"MODULE {mod}: {count} declarations"
  logInfo m!"PASS: {targets.size} safe project declarations from {modules.size} modules; dependencies {result.axioms}"
