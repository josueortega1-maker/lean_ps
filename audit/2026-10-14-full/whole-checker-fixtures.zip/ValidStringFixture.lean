import Lean
namespace Fixture
def checked : String := s!"{(show Nat from 5)}"
end Fixture
