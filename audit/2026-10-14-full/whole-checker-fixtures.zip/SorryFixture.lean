import Lean
namespace Fixture
def checked : Nat := 5
def unchecked : String := s!"{(show Nat from sorry)}"
end Fixture
