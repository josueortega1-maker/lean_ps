import Lean
namespace Fixture
opaque unchecked : String := s!"{(show Nat from sorry)}"
def checked : Nat := 5
end Fixture
