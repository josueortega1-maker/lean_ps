import Lean
namespace Fixture
axiom unexplained : Nat
def checked : Nat := 5
end Fixture
