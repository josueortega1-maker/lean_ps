Adversarial audit fixtures, intentionally separate from the proof project.

Three fixtures deliberately contain hidden proof holes and one declares a
custom axiom. They must fail the whole-declaration audit; they are not project
proofs. The two valid fixtures must pass. No compiled files are included.

The stored CurrentAudit*.lean files contain the exact checker body tested.
To reproduce on Lean 4.19.0, compile each *Fixture.lean file first with
  lean -o NAME.olean NAME.lean
then set LEAN_PATH to this extracted directory and run
  lean CurrentAuditNAME.lean
Use a normal Lean installation; the captured run_current_fixtures.py driver
records the original workspace layout and compatibility adapter, so adjust its
paths before reuse. The JSON and log files preserve the observed results.
