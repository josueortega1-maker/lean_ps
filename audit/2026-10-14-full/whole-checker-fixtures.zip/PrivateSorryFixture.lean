import Lean
namespace Fixture
private def unchecked : String := s!"{(show Nat from sorry)}"
def checked : Nat := 5
end Fixture
