import Lean
namespace Fixture
private def helper : Nat := 3
def checked : Nat := helper + 2
theorem checked_eq : checked = 5 := rfl
end Fixture
