import Main
theorem extra : True := good
