"""Minimal diagnostic: run after a normal shell build of this tiny fixture.

Uses only this fixture's generated outputs; does not touch the proof repository.
Set PATH and LD_PRELOAD to the documented local Lean runtime before running.
"""
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
build = root / ".lake/build"
old = {name: (build / f"lib/lean/{name}.olean").stat().st_mtime_ns
       for name in ["Main", "Extra"]}
with (root / "clean.log").open("w") as stream:
    subprocess.run(["lake", "--no-cache", "clean", "GuardFixture"], cwd=root,
                   stdout=stream, stderr=subprocess.STDOUT, check=True)
print("Build directory absent after clean:", not build.exists(), flush=True)
started = time.time_ns()
with (root / "build.log").open("w") as stream:
    subprocess.run(["lake", "--no-cache", "-v", "build"], cwd=root,
                   stdout=stream, stderr=subprocess.STDOUT, check=True)
print((root / "build.log").read_text())
for name in ["Main", "Extra"]:
    modified = (build / f"lib/lean/{name}.olean").stat().st_mtime_ns
    print(name, "fresh:", modified >= started, "same as previous:", modified == old[name])
